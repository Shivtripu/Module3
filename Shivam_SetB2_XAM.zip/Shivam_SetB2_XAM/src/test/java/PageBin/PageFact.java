package PageBin;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFact {
WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pfFirstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement pfLastName;
	
	@FindBy(how=How.ID, using="txtEmail")
	@CacheLookup
	WebElement pfEmail;
	
	@FindBy(how=How.ID, using="txtPhone")
	@CacheLookup
	WebElement pfPhone;
	
	@FindBy(name="size")
	@CacheLookup
	WebElement pfNoOfPeople;
	
	@FindBy(how=How.ID, using="txtAddress1")
	@CacheLookup
	WebElement pfBuilding;
	
	@FindBy(name="Address2")
	@CacheLookup
	WebElement pfArea;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement pfCity;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement pfState;
	
	@FindBy(name="memberStatus")
	@CacheLookup
	List<WebElement> pfMemberStatus;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement pfNext;
	
	//Payment Details
	@FindBy(how=How.ID, using="txtCardholderName")
	@CacheLookup
	WebElement pfCardHolderName;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement pfDebit;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement pfCVV;
	
	@FindBy(how=How.ID, using="txtMonth")
	@CacheLookup
	WebElement pfMonth;
	
	@FindBy(how=How.ID, using="txtYear")
	@CacheLookup
	WebElement pfYear;
	
	@FindBy(xpath="//*[@id='btnPayment']")
	@CacheLookup
	WebElement pfPayment;
	
	public PageFact(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setPfFirstName(String sFirstName) {
		pfFirstName.sendKeys(sFirstName);
	}

	public void setPfLastName(String sLastName) {
		pfLastName.sendKeys(sLastName);
	}

	public void setPfEmail(String sEmail) {
		pfEmail.sendKeys(sEmail);
	}

	public void setPfPhone(String sPhone) {
		pfPhone.sendKeys(sPhone);
	}

	public void setPfNoOfPeople(String sNoOfPeople) {
		Select drpPeople= new Select(pfNoOfPeople);
		drpPeople.selectByVisibleText(sNoOfPeople);
	}

	public void setPfBuilding(String sBuilding) {
		pfBuilding.sendKeys(sBuilding);
	}

	public void setPfArea(String sArea) {
		pfArea.sendKeys(sArea);
	}

	public void setPfCity(String sCity) {
		Select drpCity = new Select(pfCity);
		drpCity.selectByVisibleText(sCity);
	}

	public void setPfState(String sState) {
		Select drpState = new Select(pfState);
		drpState.selectByVisibleText(sState);
	}

	public void setPfNext() {
		pfNext.click();
	}

	public void setPfCardHolderName(String sCardHolderName) {
		pfCardHolderName.sendKeys(sCardHolderName);
	}

	public void setPfDebit(String sDebit) {
		pfDebit.sendKeys(sDebit);
	}

	public void setPfCVV(String sCVV) {
		pfCVV.sendKeys(sCVV);
	}

	public void setPfMonth(String sMonth) {
		pfMonth.sendKeys(sMonth);
	}

	public void setPfYear(String sYear) {
		pfYear.sendKeys(sYear);
	}

	public void setPfPayment() {
		pfPayment.click();
	}

	public WebElement getPfFirstName() {
		return pfFirstName;
	}

	public WebElement getPfLastName() {
		return pfLastName;
	}

	public WebElement getPfEmail() {
		return pfEmail;
	}

	public WebElement getPfPhone() {
		return pfPhone;
	}

	public WebElement getPfNoOfPeople() {
		return pfNoOfPeople;
	}

	public WebElement getPfBuilding() {
		return pfBuilding;
	}

	public WebElement getPfArea() {
		return pfArea;
	}

	public WebElement getPfCity() {
		return pfCity;
	}

	public WebElement getPfState() {
		return pfState;
	}

	public List<WebElement> getPfMemberStatus() {
		return pfMemberStatus;
	}

	public WebElement getPfNext() {
		return pfNext;
	}

	public WebElement getPfCardHolderName() {
		return pfCardHolderName;
	}

	public WebElement getPfDebit() {
		return pfDebit;
	}

	public WebElement getPfCVV() {
		return pfCVV;
	}

	public WebElement getPfMonth() {
		return pfMonth;
	}

	public WebElement getPfYear() {
		return pfYear;
	}
	public WebElement getPfPayment() {
		return pfPayment;
	}
	public void setPfMemberStatus(String sMemberStatus) {
		boolean flag=false;
		flag=pfMemberStatus.get(0).equals(sMemberStatus);
		if(flag==true)
			pfMemberStatus.get(0).click();
		else
			pfMemberStatus.get(1).click();
	}

}
