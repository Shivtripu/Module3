package Registration;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.PageFact;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private PageFact obj;
	
	
	
	
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		obj = new PageFact(driver);
		driver.get("file:///C:/Users/SHIVAMTR/Desktop/Module3%20All%20material/Set%20B/ConferenceRegistartion.html");
		
	}

	@Then("^check the title of the registration page$")
	public void check_the_title_of_the_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String title=driver.getTitle();
		if(title.contentEquals("Conference Registartion")) 
			System.out.println("Matched");
		else 
			System.out.println("NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		
	}

	@When("^user leave FirstName blank$")
	public void user_leave_FirstName_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName(""); Thread.sleep(1000);
	}

	@When("^clicks on the nextButton$")
	public void clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfNext();
	}

	@Then("^display alert message for registration$")
	public void display_alert_message_for_registration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("ALERT!" + alertMessage);
	    driver.close();
	}

	@When("^user leaves LastName blank$")
	public void user_leaves_LastName_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName(""); Thread.sleep(1000);
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
	}

	@When("^user enters incorrect email format and clicks the nextButton$")
	public void user_enters_incorrect_email_format_and_clicks_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfEmail("@shiv>@.cap>com"); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user leaves Contact blank and clicks on the nextButton$")
	public void user_leaves_Contact_blank_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone(""); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user enters incorrect Contact format and clicks the nextButton$")
	public void user_enters_incorrect_Contact_format_and_clicks_the_nextButton(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Triapthi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("123456"); Thread.sleep(1000);
		obj.setPfNext();
	}

	@When("^user does not select NumberOfPeople and clicks on the nextButton$")
	public void user_does_not_select_NumberOfPeople_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user leaves BuildingName and clicks on the nextButton$")
	public void user_leaves_BuildingName_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfBuilding(""); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
		
	}

	@When("^user leaves AreaName and clicks on the nextButton$")
	public void user_leaves_AreaName_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfBuilding("GLC Capg"); Thread.sleep(1000);
		obj.setPfArea(""); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user does not select City and clicks on the nextButton$")
	public void user_does_not_select_City_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfBuilding("GLC Capg"); Thread.sleep(1000);
		obj.setPfArea("Talwade Pune"); Thread.sleep(1000);
		obj.setPfCity("Select City"); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user does not select State and clicks on the nextButton$")
	public void user_does_not_select_State_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfBuilding("GLC Capg"); Thread.sleep(1000);
		obj.setPfArea("Talwade Pune"); Thread.sleep(1000);
		obj.setPfCity("Pune"); Thread.sleep(1000);
		obj.setPfState("Select State"); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user does not select MemberStatus and clicks on the nextButton$")
	public void user_does_not_select_MemberStatus_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfBuilding("GLC Capg"); Thread.sleep(1000);
		obj.setPfArea("Talwade Pune"); Thread.sleep(1000);
		obj.setPfCity("Pune"); Thread.sleep(1000);
		obj.setPfState("Maharashtra"); Thread.sleep(1000);
		obj.setPfMemberStatus(""); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
	}

	@When("^user enters all valid data and clicks on the nextButton$")
	public void user_enters_all_valid_data_and_clicks_on_the_nextButton() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfFirstName("Shivam"); Thread.sleep(1000);
		obj.setPfLastName("Tripathi"); Thread.sleep(1000);
		obj.setPfEmail("shivamtriapthi32@gmail.com"); Thread.sleep(1000);
		obj.setPfPhone("8400767369"); Thread.sleep(1000);
		obj.setPfNoOfPeople("2"); Thread.sleep(1000);
		obj.setPfBuilding("GLC Capg"); Thread.sleep(1000);
		obj.setPfArea("Talwade Pune"); Thread.sleep(1000);
		obj.setPfCity("Pune"); Thread.sleep(1000);
		obj.setPfState("Maharashtra"); Thread.sleep(1000);
		obj.setPfMemberStatus("non-member"); Thread.sleep(1000);
		obj.setPfNext(); Thread.sleep(1000);
		String alertMessage = driver.switchTo().alert().getText(); Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("ALERT!" + alertMessage);
	}

	@Then("^navigate to payment details page$")
	public void navigate_to_payment_details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.navigate().to("file:///C:/Users/SHIVAMTR/Desktop/Module3%20All%20material/Set%20B/PaymentDetails.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
	}

	@Given("^User is on payment page$")
	public void user_is_on_payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.get("file:///C:/Users/SHIVAMTR/Desktop/Module3%20All%20material/Set%20B/PaymentDetails.html");
	}

	@Then("^check the title of the payment page$")
	public void check_the_title_of_the_payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String title=driver.getTitle();
		if(title.contentEquals("Payment Details")) 
			System.out.println("Title Matched");
		else 
			System.out.println("Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}

	@When("^user leaves CardHolderName blank$")
	public void user_leaves_CardHolderName_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfCardHolderName(""); Thread.sleep(1000);
	}

	@When("^clicks the makePayment button$")
	public void clicks_the_makePayment_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfPayment(); Thread.sleep(1000);
	}

	@Then("^display alert meassage for payment$")
	public void display_alert_meassage_for_payment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("ALERT!" + alertMessage);
	    driver.close();
	}

	@When("^user leaves DebitCardNo blank$")
	public void user_leaves_DebitCardNo_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfCardHolderName("Shivam Tripathi"); Thread.sleep(1000);
		obj.setPfDebit(""); Thread.sleep(1000);
	}

	@When("^user leaves expirationMonth blank and clicks the makePayment button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_makePayment_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfCardHolderName("Shivam Tripathi"); Thread.sleep(1000);
		obj.setPfDebit("9876 5612 3214 5687"); Thread.sleep(1000);
		obj.setPfCVV("955"); Thread.sleep(1000);
		obj.setPfMonth(""); Thread.sleep(1000);
		obj.setPfPayment(); Thread.sleep(1000);
	}

	@When("^user leaves expirationYr blank and clicks the makePayment button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_makePayment_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfCardHolderName("Shivam Tripathi"); Thread.sleep(1000);
		obj.setPfDebit("9876 5612 3214 5687"); Thread.sleep(1000);
		obj.setPfCVV("955"); Thread.sleep(1000);
		obj.setPfMonth("12"); Thread.sleep(1000);
		obj.setPfYear(""); Thread.sleep(1000);
		obj.setPfPayment(); Thread.sleep(1000);
	}

	@When("^user enters all valid data and clicks on the makePayment button$")
	public void user_enters_all_valid_data_and_clicks_on_the_makePayment_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		obj.setPfCardHolderName("Shivam Tripathi"); Thread.sleep(1000);
		obj.setPfDebit("9876 5612 3214 5687"); Thread.sleep(1000);
		obj.setPfCVV("955"); Thread.sleep(1000);
		obj.setPfMonth("12"); Thread.sleep(1000);
		obj.setPfYear("2025"); Thread.sleep(1000);
		obj.setPfPayment(); Thread.sleep(1000);
	}

}
